INSERT INTO `artikal` (`artikal_id`, `naziv_artikla`, `vrsta_artikla`, `cijena`) VALUES (1, 'Waltz Cream', 'Čokoladni namaz', 3.90);
INSERT INTO `artikal` (`artikal_id`, `naziv_artikla`, `vrsta_artikla`, `cijena`) VALUES (2, 'Marlboro', 'Cigarete', 6.00);
INSERT INTO `artikal` (`artikal_id`, `naziv_artikla`, `vrsta_artikla`, `cijena`) VALUES (3, 'Fructal', 'Sok', 1.95);
INSERT INTO `artikal` (`artikal_id`, `naziv_artikla`, `vrsta_artikla`, `cijena`) VALUES (4, 'Dvojni C', 'Sok', 0.50);
INSERT INTO `artikal` (`artikal_id`, `naziv_artikla`, `vrsta_artikla`, `cijena`) VALUES (5, 'Eurovafel', 'Keks', 1.55);
