INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (1, 'Azra', 'Pamuk', 'Sarajevo', 'Bunica 41', '062614454', 'azra.pamuk', 'admin');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (2, 'Amer', 'Pamuk', NULL, NULL, NULL, 'amer.pamuk', 'amer');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (3, 'Irma', 'Pamuk', NULL, NULL, NULL, 'irma.pamuk', 'irma');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (4, 'Edin', 'Pamuk', NULL, NULL, NULL, 'edin.pamuk', 'edin');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (5, 'Amina', 'Bicić', NULL, NULL, NULL, 'amina', 'jej');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (6, 'Faruk', 'Hodžić', NULL, NULL, NULL, 'faruk', 'skr');
INSERT INTO `kupac` (`kupac_id`, `ime`, `prezime`, `grad`, `adresa`, `telefon`, `user`, `pass`) VALUES (7, 'Lejla', 'Majić', '', '', '', 'lejla', 'jejeje');
